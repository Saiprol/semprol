<p align="center"><img src="https://i.ibb.co/3F6V9JQ/MHDDoS.png" width="400px" height="150px" alt="𝙆𝙧𝙞𝙯𝙯𝙕𝙈𝙤𝙙𝙯 🇵🇪 𝙊𝙁𝘾"></p>

<h1 align="center">KrizzZModz 🇵🇪 OFC  Attack Script With 56 Methods</h1>
<em><h5 align="center">(Programming Language - Python 3)</h5></em>


* ⚙️ Tools - Runs With 
`
python3 start.py tools
`
  * 🌟 CFIP | Find Real IP Address Of Websites Powered By Cloudflare
  * 🔪 DNS | Show DNS Records Of Sites
  * 📍  TSSRV | TeamSpeak SRV Resolver
  * ⚠  PING | PING Servers
  * 📌 CHECK | Check If Websites Status
  * 😎 DSTAT | That Shows Bytes Received, bytes Sent and their amount

* 🎩 Other
  * ❌ STOP | STOP All Attacks
  * 🌠 TOOLS | Console Tools
  * 👑 HELP | Show Usage Script

  
<h1 align="center">
Our social's💻
  
</h2> 

<h1 style="color:red;text-align: center;" style="text-align: center;" align="center">Please do not use the "Issues" section to ask your questions!</h1>
<div align="center">
   <img src="https://icon-library.com/images/github-icon-vector/github-icon-vector-27.jpg" width="64" height="64"/>
   <img src="https://brandlogos.net/wp-content/uploads/2021/11/discord-logo.png"  width="64" height="64" alt="discord" />
   <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Telegram_logo.svg/2048px-Telegram_logo.svg.png" width="64" height="64" alt="telegram" />
</div>

 * [KrizzZModz 🇵🇪 OFC Telegram Channel](https://t.me/KrizzZModzOFC3)
 * [KrizzZModz 🇵🇪 OFC YouTube Channel](https://youtube.com/@krizzzmodzofc3)
 * [Crash BOT Group](https://t.me/crashbotff)
### If u Like the project, leave a star on the repository!

## Downloads

You can download it from [YouTube Releases](https://youtube.com/@krizzzmodzofc3)

### Getting Started

**Requirements**

* [dnspython](https://github.com/rthalley/dnspython)
* [cfscrape](https://github.com/Anorov/cloudflare-scrape)
* [impacket](https://github.com/SecureAuthCorp/impacket)
* [requests](https://github.com/psf/requests)
* [Python3][python3]
* [PyRoxy](https://github.com/KzTeam/PyRoxy)
* [icmplib](https://github.com/ValentinBELYN/icmplib)
* [certifi](https://github.com/certifi/python-certifi)
* [psutil](https://github.com/giampaolo/psutil)
* [yarl](https://github.com/aio-libs/yarl)
---

## Documentation

You can read it from [GitHub Wiki](https://github.com/crisslyricsoficial/KzTeam/wiki)

**Clone and Install Script**

```shell script
git clone https://github.com/crisslyricsoficial/KzTeam.git
cd MHDDoS
pip install -r requirements.txt
```

**One-Line Installing on Fresh VPS**

```shell script
apt -y update && apt -y install curl wget libcurl4 libssl-dev python3 python3-pip make cmake automake autoconf m4 build-essential git && git clone https://github.com/crisslyricsoficial/KzTeam.git && cd MH* && pip3 install -r requirements.txt
```

[python3]: https://python.org 'Python3'
[github issues]: https://github.com/crisslyricsoficial/KzTeam/issues 'enter'

---

## Need a Cheap Hourly Server? No Problem

<a href="https://aeza.net/?ref=375036"><img src="https://i.ibb.co/wgq9Ly8/aezabanner.png" width="728" height="90" alt="aeza"></a>

#### You can buy an hourly 10Gbps server from [Aeza Hosting](https://aeza.net/?ref=375036) with crypto (100% anonymous).
